<?php
require_once('connect.php');
$cmd = $_REQUEST['cmd'];

if($cmd == "get_user_details"){
	$tbl_id = $_REQUEST['tbl_id'];
	$out_put = array();
	$query = "SELECT * FROM tickets WHERE id='$tbl_id'";
	$statement = $connection->prepare($query);
	$statement->execute();
	$row = $statement->fetch(PDO::FETCH_ASSOC);	
	
	echo json_encode($row);
}

?>
