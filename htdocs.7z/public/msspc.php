<?php
	require_once "connect.php";
	$sqli = mysqli_connect("localhost", "root", "", "test") or die("Could not connect database...");
	$update = false;
	$id = $name = $sal = "";
	if (isset($_REQUEST['edit'])) {
		$id = $_REQUEST['edit'];
		$update = true;

		$query = "SELECT * FROM emp WHERE empno='$id'";
		$statement = $connection->prepare($query);
		$statement->execute();
	
		if ($statement->rowCount() == 1 ) {
			$row = $statement->fetch(PDO::FETCH_ASSOC);	
			$id = $row['EMPNO'];
			$name = $row['EMPNAME'];
			$sal = $row['SAL'];
		}

	}
	
	if(isset($_REQUEST['save'])){
		$id = $_REQUEST['id'];
		$name = $_REQUEST['name'];
		$sal = $_REQUEST['salary'];

		$query = "INSERT INTO emp (empno, empname, sal) VALUES ('$id', '$name', '$sal')";
		$statement = $connection->prepare($query);
		$statement->execute();

		$_SESSION['msg'] = "Employee Saved";
		header("location:msspc.php");
	}

	if(isset($_REQUEST['update'])){
		$id = $_REQUEST['id'];
		$name = $_REQUEST['name'];
		$sal = $_REQUEST['salary'];

		$query = "UPDATE emp SET empname = '$name', sal = $sal WHERE empno = $id";
		$statement = $connection->prepare($query);
		$statement->execute();

		$_SESSION['msg']= "Employee Data Updated.";
		header("location:msspc.php");
		
	}

	if(isset($_REQUEST['del'])){
		$id = $_REQUEST['del'];

		$query = "DELETE FROM emp WHERE empno = $id";
		$statement = $connection->prepare($query);
		$statement->execute();

		$_SESSION['msg'] = "Employee Data is deleted";
		header("location:msspc.php");
	}


?>
<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="css/msstyle.css">
	<script type="text/javascript">
		function clear(){
			document.getElementsByTagName('id').clear();
			document.getElementsByTagName('name').clear();
			document.getElementsByTagName('salary').clear();
		}
		function back(){
			 window.location.href = "https://www.google.com";
		}
	</script>
</head>
<body>	
		<?php

			if(isset($_SESSION['msg'])){
				echo "<div class='msg'>";
				echo $_SESSION['msg'];
				unset($_SESSION['msg']);
				echo "</div>";
			}
			$query = mysqli_query($sqli, "SELECT * FROM emp");
		?>
		<table>
				<tr>
					<td>Name</td>
					<td>Salary</td>
					<td colspan="2">Action</td>
				</tr>
				<?php
					while($row = mysqli_fetch_array($query)){
						echo "<tr>";
						
						echo "<td>".$row["EMPNAME"]."</td>";
						echo "<td>".$row['SAL']."</td>";
						echo "<td><a class='link' href=msspc.php?edit=".$row['EMPNO'].">Edit</a></td>";
						echo "<td><a class='link' href=msspc.php?del=".$row['EMPNO'].">Delete</a></td>";
						echo "</tr>";
					}
				?>
		</table>
		<form action="#" method="POST">
			<div class="input-group">
				<label>Employee No.</label>
				<input type="text" name="id" value="<?php echo $id; ?>">
			</div>
			<div class="input-group">
				<label>Name</label>
				<input type="text" name="name" value="<?php echo $name; ?>">
			</div>
			<div class="input-group">
				<label>Salary</label>
				<input type="text" name="salary" value="<?php echo $sal; ?>">
			</div>
			<div class="input-group">
				<?php if($update == true) { ?>
				 <button class="btn" type="submit" name="update" style="background: red;" onclick="back()"> Update </button>
				 <?php } elseif ($update == false) { ?>
				 	<button class="btn" type="submit" name="save" onclick="clear()"> Save </button>
				 <?php } ?>
			</div>
		</form>
		<div class="footer">Shree Developers</div>
</body>
</html>
