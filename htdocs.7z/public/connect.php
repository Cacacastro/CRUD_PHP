<?php
    require_once "../config.php";
    require_once "../common.php";
    try {
        $connection = new PDO($dsn, $username, $password, $options);
    } catch(PDOException $error) {
        echo "Erro ao conectar<br>" . $error->getMessage();
    }
?>

