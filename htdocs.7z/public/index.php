<?php require_once('connect.php'); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Registro de Tickets </title>
   
    <!-- Bootstrap Core Css -->
    <link href="css/bootstrap.css" rel="stylesheet" />

    <!-- Font Awesome Css -->
    <link href="css/font-awesome.min.css" rel="stylesheet" />

	<!-- Bootstrap Select Css -->
    <link href="css/bootstrap-select.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="css/app_style.css" rel="stylesheet" />
</head>
<body>
    <div class="all-content-wrapper">
        
        <section class="container">
            <div class="form-group custom-input-space has-feedback">
                <div class="page-heading">
                    <h3>Registro de Tickets</h3>
                </div>
                <div class="page-body clearfix">
                    <!-- form -->
                    <form id="hl_form" name="hl_form">
					<input type="hidden" id="form_name" name="form_name" value="add_user" />
                    <input type="hidden" id="edit_id" name="edit_id" value="0" />
					<input type="hidden" id="old_password" name="old_password" value="" />
                    <div class="row">
                        <div class="col-md-offset-2 col-md-8">
                            <div class="panel panel-default">
                                <div class="panel-heading">Informações do ticket:</div>
                                <div class="panel-body">
                                    <div class="alert icon-alert with-arrow alert-success form-alter" role="alert">
                                        <i class="fa fa-fw fa-check-circle"></i>
                                        <strong> Successo ! </strong> Dados salvos com sucesso. 
                                    </div>
                                    <div class="alert icon-alert with-arrow alert-danger form-alter" role="alert">
                                        <i class="fa fa-fw fa-times-circle"></i>
                                        <strong> Negado !</strong> Falha ao salvar dados. 
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="numero" class="required" >Número do ticket:</label>
                                            <input type="text" class="form-control" name="numero" id="numero" required />
                                        </div>
                                        <div class="form-group">
                                            <label for="usuario" class="required" >Usuário:</label>
                                            <input type="text" class="form-control dup-check"name="usuario" id="usuario" required />
                                            <span class="dup-chek-details"></span>
                                        </div>
                                        <div class="form-group">
                                            <label for="descricao" >Descrição:</label>
                                            <input type="text" class="form-control" name="descricao" id="descricao" />
                                        </div>
                                        <div class="form-group">
                                            <label for="data_tic" class="required">Data de abertura:</label>
                                            <input type="date" class="form-control" name="data_tic" id="data_tic" required/>
                                        </div>
                                        
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="categoria" class="required" >Categoria:</label>
                                            <input type="text" class="form-control" name="categoria" id="categoria" required />
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="aberto_por" class="required" >Aberto por:</label>
                                            <input type="text" class="form-control" name="aberto_por" id="aberto_por" required />
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="situacao" class="required" >Status:</label>
                                            <input type="text" class="form-control" name="situacao" id="situacao" required />
                                        </div>
                                    </div>
                                    
                                    <div class="clearfix"></div>
                                    <div class="form-action-group">
                                        <button type="button" class="btn btn-primary btn-form-action btn-submit">Cadastrar</button>
                                        <button type="button" class="btn btn-danger btn-form-action btn-reset">Limpar</button>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    </form>
                    <!-- #END# form -->

                    <div class="panel panel-default">
                        <div class="panel-heading">Lista de tickets:</div>
                        <div class="panel-body">
                            <!-- My Documents start -->
                            <div class="table-responsive">
                                <table class="table table-striped table-hover js-basic-example dataTable">
                                    <thead>
                                        <tr>
                                            <th width="100px">ID</th>
											<th>Número do ticket</th>
                                            <th>Usuário</th>
                                            <th>Data</th>
                                            <th>Categoria</th>
											<th>Descrição</th>
                                            <th>Aberto Por</th>
											<th>Status</th>
                                            <th width="150px">Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $sno = 1;
                                    $query = "select * from tickets";
                                    $statement = $connection->prepare($query);
                                    $statement->execute();
                                    $result = $statement->fetchAll();


                                    foreach ($result as $row) {
                                    ?>
                                        <tr>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo $row['numero']; ?></td>
                                            <td><?php echo $row['usuario']; ?></td>
                                            <td><?php echo $row['data_tic']; ?></td>
                                            <td><?php echo $row['categoria']; ?></td>
											<td><?php echo $row['descricao']; ?></td>
											<td><?php echo $row['aberto_por']; ?></td>
											<td><?php echo $row['situacao']; ?></td>
                                            <td align="center">
                                                <div class="form-group">
                                                    <button type="button" class="btn btn-sm btn-primary btn-edit" id="<?php echo $row['id']; ?>" title="Editar" >
                                                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                                    </button>
                                                    <button type="button" class="btn btn-sm btn-danger btn-delete" id="<?php echo $row['id']; ?>" title="Apagar" data-toggle="modal" data-target="#confirmModal" >
                                                        <i class="fa fa-trash-o" aria-hidden="true"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- #END# My Documents -->
                        </div>
                    </div>

                </div>
            </div>
        </section>
    </div>
	
	<!-- Jquery Core Js -->
    <script src="js/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Bootstrap Select Js -->
    <script src="js/bootstrap-select.js"></script>

	<!-- validate Js -->
	<script type="text/javascript" src="js/jquery.validate.min.js"></script>
	
	<script>

    $(document).ready(function(e){
		$("#hl_form").validate({
			// Specify the validation rules
			rules: {
				numero: {
					required: true
				},
				usuario: {
					required: true
				},
				data_tic: {
					required: true
				},
				categoria: {
					required: true
				},
				aberto_por: {
					required: true
				},
				situacao: {
					required: true
				}
			},
			
			// Specify the validation error messages
			messages: {
				numero: "Insira o número do ticket!",
				usuario: "Insira o usuário!",
				data_tic: {
					required: "Insira uma data!"
					
				},
				categoria: {
					required: "Insira uma categoria!"
				},
				aberto_por: "Insira o autor do ticket!",
				situacao: "Insira a situação!"
			},
			submitHandler: function(form) {
				form.submit();
			}
		});

		$(document).on('click', '.btn-submit', function(ev){
			ev.preventDefault();
			var btn_button = $(this);
			if($("#hl_form").valid() == true){
				var data = $("#hl_form").serialize();
				btn_button.html(' <i class="fa fa fa-spinner fa-spin"></i> Processando...');
				btn_button.attr("disabled",true);
				$("#form_name").val("add_user");
				$.post('save_details.php', data, function(data,status){
					console.log("Data: " + data + "\nStatus: " + status);
					if( data.trim() == "1"){
						//alert("Data: " + data + "\nStatus: " + status);
						$(".alert-danger").hide();
						$(".alert-success").fadeIn(800);
						btn_button.html('<i class="fa fa fa-check-circle"></i> Sucesso');
						setTimeout(function(){  location.reload(); }, 2000);
					}
					else{
						//alert("Data: " + data + "\nStatus: " + status);
						$(".alert-success").hide();
						$(".alert-danger").fadeIn(800);
						btn_button.html('Confirmar').attr("disabled",false);
					}
				});
			}
		});

		$(document).on('click', '.btn-reset', function(ev){
			ev.preventDefault();
			$("#form_name").val("add_user");
			$("#edit_id").val('');
			$("#numero").val('');
			$("#usuario").val('');
			$("#descricao").val('');
			$("#data_tic").val('');
			$("#categoria").val('');
			$("#aberto_por").val('');
			$("#situacao").val('');
		});

        $(document).on('click', '.btn-edit', function(ev){
			ev.preventDefault();
			var btn_button = $(this);
			btn_button.html(' <i class="fa fa fa-spinner fa-spin"></i> ');
			var tbl_id = $(this).attr("id");
			$('.btn-reset').trigger('click');
			$.ajax({
			  cache: false,
			  url: 'get_ajax_details.php', // url where to submit the request
			  type : "GET", // type of action POST || GET
			  dataType : 'json', // data type
			  data : { cmd: "get_user_details", tbl_id: tbl_id }, // post data || get data
			  success : function(result) {
				btn_button.html(' <i class="fa fa fa-pencil-square-o"></i> ');
				console.log(result);
				$("#form_name").val("edit_user");
				$("#edit_id").val(result['id']);
				$("#numero").val(result['numero']).focus();
				$("#usuario").val(result['usuario']);
				$("#descricao").val(result['descricao']);
				$("#data_tic").val(result['data_tic']);
				$("#categoria").val(result['categoria']);
				$("#aberto_por").val(result['aberto_por']);
				$("#situacao").val(result['situacao']);
				
			  },
			  error: function(xhr, resp, text) {
				console.log(xhr, resp, text);
			  }
			});
		});


		$(document).on('click', '.btn-confirm-delete', function(ev){
			ev.preventDefault();
			var btn_button = $(this);
			var tbl_id = $('.btn-confirm-delete').attr("id");
			$('#confirmModal').modal('hide');
			
			$.post('save_details.php', { form_name: "del_user", tbl_id: tbl_id }, function(data,status){
				console.log(data);
				if(data.trim() == "1"){
					btn_button.html('<i class="fa fa fa-check-circle "></i> Sucesso');
					$('.warning-modal-message').html("Dados deletados com sucesso.");
					$('#warningModal').modal('show');
					setTimeout(function(){  location.reload(); }, 2000);
				}
				else if(data == "404-del"){
					//$('.warning-modal-message').html("This details reflect in another record. So you can't delete !!!");
					$('#warningModal').modal('show');
				}
				else{
					$('.warning-modal-message').html("Falha ao deletar.");
					btn_button.html('Confirmar');
				}
			});
		});
		
		$(document).on('click', '.btn-delete', function(ev){
			ev.preventDefault();
			$(".btn-confirm-delete").attr("id",$(this).attr('id'));
		});
		
		$(document).on('click', '.btn-confirm-close', function(ev){
			ev.preventDefault();
			$(".btn-confirm-delete").attr("id","0");
		});

		
	});    
	</script>

	<!-- Small Size -->
	<div class="modal fade" id="confirmModal" tabindex="-1" role="dialog">
		<div class="modal-dialog modal-md" role="document">
			<div class="modal-content modal-col-danger">
				<div class="modal-header">
					<h4 class="modal-title" id="smallModalLabel">Confirmar</h4>
				</div>
				<div class="modal-body">
					Deseja apagar estes dados ?
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default btn-confirm-delete">Confirmar</button>
					<button type="button" class="btn btn-default btn-confirm-close" data-dismiss="modal">Fechar</button>
				</div>
			</div>
		</div>
	</div>


	<!-- Small Size -->
	<div class="modal fade" id="warningModal" tabindex="-1" role="dialog">
		<div class="modal-dialog modal-md" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title" id="smallModalLabel">Info:</h4>
				</div>
				<div class="modal-body warning-modal-message">
					
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default btn-warning-close" data-dismiss="modal">Fechar</button>
				</div>
			</div>
		</div>
	</div>

</body>
</html>
