<?php
require_once('connect.php');
require_once('../common.php');

$form_name = $_POST['form_name'];

$created_at = $updated_at = date("d/m/Y");
$created_by = $updated_by = 0;
$updated_addon_query = " updated_at='$updated_at', updated_by='$updated_by' ";

if($form_name == 'add_user'){
	try {
		$new_user = array(
			"numero" => $_POST['numero'],
			"usuario"  => $_POST['usuario'],
			"descricao" => $_POST['descricao'],
			"data_tic"     => $_POST['data_tic'],
			"categoria"       => $_POST['categoria'],
			"aberto_por"  => $_POST['aberto_por'],
			"situacao" => $_POST['situacao']	  
		);
	
		$sql = sprintf(
			"INSERT INTO %s (%s) VALUES (%s)",
			"tickets",
			implode(", ", array_keys($new_user)),
			":" . implode(", :", array_keys($new_user))
				);
			
				$statement = $connection->prepare($sql);
				$statement->execute($new_user);
				echo "1";
			  } catch(PDOException $error) {
				echo $sql . "<br>" . $error->getMessage();
			  }
}

if($form_name == "edit_user"){
	try {
		$user =[
			"id"           	=> $_POST['edit_id'],
			"numero" => $_POST['numero'],
			"usuario"  => $_POST['usuario'],
			"descricao" => $_POST['descricao'],
			"data_tic"     => $_POST['data_tic'],
			"categoria"       => $_POST['categoria'],
			"aberto_por"  => $_POST['aberto_por'],
			"situacao" => $_POST['situacao']
		];
		
		$sql = "UPDATE tickets
		SET id = :id,
			numero = :numero,
			usuario = :usuario,
			descricao = :descricao,
			data_tic = :data_tic,
			categoria = :categoria,
			aberto_por = :aberto_por,
			situacao = :situacao
		WHERE id = :id";

		$statement = $connection->prepare($sql);
		$statement->execute($user);
		echo "1";
	} catch(PDOException $error) {
		echo($sql . "\n" . $error->getMessage());
	}
}

if($form_name == "del_user"){
	$chk_val = 0;
	$tbl_id = escape($_POST['tbl_id']);
	
	if( $chk_val == 0){
		try {
			$sql = "DELETE FROM tickets WHERE id=:tbl_id";
			$statement = $connection->prepare($sql);
			$statement->bindParam(':tbl_id', $tbl_id, PDO::PARAM_STR);
			$statement->execute();
			echo "1";
		} catch(PDOException $error) {
			echo($sql . "\n" . $error->getMessage());
		}
	}
	else{
		echo "404-del";
	}
}

?>