CREATE DATABASE test;

  use test;

  CREATE TABLE tickets (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    numero VARCHAR(20) NOT NULL,
    usuario VARCHAR(50) NOT NULL,
    descricao VARCHAR(300) NOT NULL,
    data_tic date NOT NULL,
    categoria VARCHAR(200) NOT NULL,
    aberto_por VARCHAR(50) NOT NULL,
    situacao VARCHAR(30) NOT NULL, 
  );